console.log("Entramos");
var items= document.getElementsByClassName("item");
var cantidad = items.length;
console.log("cantidad de listas  " + cantidad);

var div=document.createElement("div");

div;

div.innerText="aprendiendo javascript";

var divuno=document.getElementById("uno");

divuno.appendChild(div);

var lista=document.getElementById("lista");

var hijo= document.createElement("li");
hijo.innerText="nueva linea";
lista.appendChild(hijo);

document.getElementById("tres").style.color="red";
document.getElementById("lista").style.color="green";

document.body.style.backgroundColor="blue";

var divdos=document.createElement("div");
divdos.style.backgroundcolor="blue";
var parrafo=document.createElement("p");
parrafo.innerText="Había una vez un conejito soñador que vivía en una casita en medio del bosque, rodeado de libros y fantasía, pero no tenía amigos. Todos le habían dado de lado porque se pasaba el día contando historias imaginarias sobre hazañas caballerescas, aventuras submarinas y expediciones extraterrestres. Siempre estaba inventando aventuras como si las hubiera vivido de verdad, hasta que sus amigos se cansaron de escucharle y acabó quedándose solo."
var listados=document.createElement("ul");
var contenido=document.createElement("li");
contenido.innerText="contenido";
lista2.appendChild(contenido);
divdos.appendChild(parrafo);
divdos.appendChild(lista2);


